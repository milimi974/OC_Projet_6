-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Dim 14 Janvier 2018 à 11:02
-- Version du serveur :  5.5.58-0+deb8u1
-- Version de PHP :  5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `oc_pizza`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `product_id` int(11) NOT NULL,
  `order_number` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `articles`
--

INSERT INTO `articles` (`product_id`, `order_number`, `quantity`) VALUES
(1, 1, 2),
(1, 2, 1),
(2, 1, 4),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Structure de la table `bills`
--

CREATE TABLE IF NOT EXISTS `bills` (
`bill_number` int(11) NOT NULL,
  `order_number` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bills`
--

INSERT INTO `bills` (`bill_number`, `order_number`, `status`, `created`, `modified`) VALUES
(1, 1, 0, '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(2, 2, 1, '2018-01-11 00:00:00', '2018-01-11 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `compositions`
--

CREATE TABLE IF NOT EXISTS `compositions` (
  `product_id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compositions`
--

INSERT INTO `compositions` (`product_id`, `ingredient_id`, `quantity`) VALUES
(1, 3, 1),
(1, 4, 2),
(1, 11, 1),
(2, 6, 1),
(2, 9, 2),
(2, 12, 1);

-- --------------------------------------------------------

--
-- Structure de la table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `user_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `employees`
--

INSERT INTO `employees` (`user_id`, `shop_id`) VALUES
(1, 1),
(2, 1),
(4, 1),
(1, 2),
(5, 2),
(6, 2);

-- --------------------------------------------------------

--
-- Structure de la table `ingredients`
--

CREATE TABLE IF NOT EXISTS `ingredients` (
`id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `created`, `modified`) VALUES
(1, 'sel', '2017-12-12 00:00:00', '2017-11-30 20:27:33'),
(2, 'oignon', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(3, 'sauce tomate', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(4, 'mozzarella', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(5, 'farine', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(6, 'oeuf', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(7, 'lardon', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(8, 'thon', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(9, 'crème fraiche', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(10, 'chorrizzo', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(11, 'pâte medium', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(12, 'pâte moyenne', '2018-01-11 00:00:00', '2018-01-11 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
`number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `deliveryman_id` int(11) DEFAULT NULL,
  `online` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `status_gestion` char(20) NOT NULL,
  `delivery_time` datetime NOT NULL,
  `delivery` tinyint(1) DEFAULT NULL,
  `price_ht` int(11) NOT NULL DEFAULT '0',
  `tva_rate` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `orders`
--

INSERT INTO `orders` (`number`, `user_id`, `shop_id`, `customer_id`, `deliveryman_id`, `online`, `status`, `status_gestion`, `delivery_time`, `delivery`, `price_ht`, `tva_rate`, `created`, `modified`) VALUES
(1, 2, 1, 3, NULL, 1, 0, 'en préparation', '2018-01-11 01:00:00', 0, 0, 10, '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(2, 3, 2, 3, 4, 1, 0, 'en livraison', '2018-01-11 00:33:00', 0, 0, 10, '2018-01-10 00:00:00', '2018-01-10 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `payement_modes`
--

CREATE TABLE IF NOT EXISTS `payement_modes` (
`id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `payement_modes`
--

INSERT INTO `payement_modes` (`id`, `name`, `active`) VALUES
(1, 'chèque', 1),
(2, 'espèces', 1),
(3, 'carte bancaire', 1),
(4, 'ticket restaurant', 1);

-- --------------------------------------------------------

--
-- Structure de la table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `bill_number` int(11) NOT NULL,
  `payment_mode_id` int(11) NOT NULL,
  `price_ttc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `payments`
--

INSERT INTO `payments` (`bill_number`, `payment_mode_id`, `price_ttc`) VALUES
(1, 2, 0),
(2, 3, 25);

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `disponibility` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `recipes` text,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `products`
--

INSERT INTO `products` (`id`, `name`, `disponibility`, `description`, `recipes`, `created`, `modified`) VALUES
(1, 'pizza royal', 1, 'une pizza royal', 'petite pâte\r\nsauce tomate\r\nmozzarela', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(2, 'pizza reine', 1, 'une pizza reine', 'pâte moyenne\r\ncrème fraîche\r\nœuf', '2018-01-11 00:00:00', '2018-01-11 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `role_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `roles`
--

INSERT INTO `roles` (`role_name`) VALUES
('Caissier'),
('Client'),
('Directeur'),
('Livreur');

-- --------------------------------------------------------

--
-- Structure de la table `shops`
--

CREATE TABLE IF NOT EXISTS `shops` (
`id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `zip_code` mediumint(8) unsigned NOT NULL,
  `city` varchar(50) NOT NULL,
  `longitude` decimal(10,6) NOT NULL DEFAULT '0.000000',
  `latitude` decimal(10,6) NOT NULL DEFAULT '0.000000',
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `schedules` text,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `shops`
--

INSERT INTO `shops` (`id`, `name`, `address`, `zip_code`, `city`, `longitude`, `latitude`, `phone_number`, `email`, `schedules`, `created`, `modified`) VALUES
(1, 'Magasin 1', '35 avenue de la paix', 67000, 'strasbourg', 0.000000, 0.000000, '0388252515', 'mag1@oc_pizza.Fr', NULL, '2018-01-01 00:00:00', '2018-01-01 00:00:00'),
(2, 'Magasin 2', '3 bld de la victoire', 67100, 'strasbourg', 0.000000, 0.000000, '0388454745', 'mag2@oc_pizza.Fr', NULL, '2017-12-12 00:00:00', '2017-12-12 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `stocks`
--

CREATE TABLE IF NOT EXISTS `stocks` (
  `shop_id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `sell_price_ht` int(11) NOT NULL,
  `purchase_price_ht` int(11) NOT NULL,
  `purchase_tva_rate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `stocks`
--

INSERT INTO `stocks` (`shop_id`, `ingredient_id`, `quantity`, `sell_price_ht`, `purchase_price_ht`, `purchase_tva_rate`) VALUES
(1, 1, 10, 255000, 125800, 21),
(1, 2, 50, 180000, 100000, 21),
(1, 3, 25, 450000, 240000, 21),
(1, 4, 80, 240000, 120000, 21),
(1, 5, 45, 80000, 50000, 21),
(1, 6, 89, 130000, 90000, 21),
(1, 7, 64, 240000, 130000, 21),
(1, 8, 64, 70000, 40000, 21),
(1, 11, 50, 60000, 35000, 21),
(1, 12, 125, 75000, 38000, 21),
(2, 3, 25, 450000, 240000, 21),
(2, 4, 80, 240000, 120000, 21),
(2, 5, 45, 80000, 50000, 21),
(2, 6, 89, 130000, 90000, 21),
(2, 7, 64, 240000, 130000, 21),
(2, 8, 64, 70000, 40000, 21),
(2, 11, 50, 60000, 35000, 21),
(2, 12, 125, 75000, 38000, 21);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `login` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `zip_code` mediumint(9) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `role_name`, `login`, `password`, `firstname`, `name`, `address`, `zip_code`, `city`, `longitude`, `latitude`, `phone_number`, `email`, `created`, `modified`) VALUES
(1, 'Directeur', 'directeur', '60d5f0s5df05df05df0s56f40s6d5f4s06df54df0', 'pierre', 'le directeur', '35 avenue de la paix', 67200, 'strasbourg', 17.005000, 4.054120, NULL, 'directeur@oc_pizza.fr', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(2, 'Caissier', 'caissier', '60d5f0s5df05df05df0s56f40s6d5f4s06df54df0', 'éric', 'le caissier', NULL, NULL, NULL, NULL, NULL, NULL, 'caisser@oc_pizza.fr', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(3, 'Client', 'client', '60d5f0s5df05df05df0s56f40s6d5f4s06df54df0', 'pauline', 'la client', '5 rue de la victoire', 67005, 'strasbourg', 17.005000, 4.054120, NULL, 'cliente@gmail.fr', '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(4, 'Livreur', 'livreur', '60sdf4s605df46sq5d0f460qf406fds5406qsf', 'jack', 'le livreur', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(5, 'Caissier', 'caissier 2', '68s2q46f84c2ef42q6sdfqf5ds5f46qsqdfxf4q65', 'loic', 'le caissier 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-01-11 00:00:00', '2018-01-11 00:00:00'),
(6, 'Livreur', 'livreur 2', 'sdf35426qsf4264df6qs4df624qs62fd42cqf46c', 'pierre', 'le livreur 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-01-11 00:00:00', '2018-01-11 00:00:00');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
 ADD PRIMARY KEY (`product_id`,`order_number`), ADD KEY `orders_articles_fk` (`order_number`);

--
-- Index pour la table `bills`
--
ALTER TABLE `bills`
 ADD PRIMARY KEY (`bill_number`), ADD KEY `bills_idx` (`bill_number`), ADD KEY `orders_bills_fk` (`order_number`);

--
-- Index pour la table `compositions`
--
ALTER TABLE `compositions`
 ADD PRIMARY KEY (`product_id`,`ingredient_id`), ADD KEY `ingredients_compositions_fk` (`ingredient_id`);

--
-- Index pour la table `employees`
--
ALTER TABLE `employees`
 ADD PRIMARY KEY (`user_id`,`shop_id`), ADD KEY `shops_employees_fk` (`shop_id`);

--
-- Index pour la table `ingredients`
--
ALTER TABLE `ingredients`
 ADD PRIMARY KEY (`id`), ADD KEY `ingredients_idx1` (`name`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
 ADD PRIMARY KEY (`number`), ADD KEY `orders_idx` (`number`), ADD KEY `shops_orders_fk` (`shop_id`), ADD KEY `users_orders_fk2` (`customer_id`), ADD KEY `users_orders_fk1` (`user_id`), ADD KEY `users_orders_fk` (`deliveryman_id`);

--
-- Index pour la table `payement_modes`
--
ALTER TABLE `payement_modes`
 ADD PRIMARY KEY (`id`), ADD KEY `payement_modes_idx` (`id`);

--
-- Index pour la table `payments`
--
ALTER TABLE `payments`
 ADD PRIMARY KEY (`bill_number`,`payment_mode_id`), ADD KEY `payement_modes_payments_fk` (`payment_mode_id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`), ADD KEY `products_idx` (`id`), ADD KEY `products_idx1` (`name`);

--
-- Index pour la table `roles`
--
ALTER TABLE `roles`
 ADD PRIMARY KEY (`role_name`);

--
-- Index pour la table `shops`
--
ALTER TABLE `shops`
 ADD PRIMARY KEY (`id`), ADD KEY `shops_idx` (`name`);

--
-- Index pour la table `stocks`
--
ALTER TABLE `stocks`
 ADD PRIMARY KEY (`shop_id`,`ingredient_id`), ADD KEY `ingredients_stocks_fk` (`ingredient_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD KEY `users_idx` (`login`,`password`,`email`), ADD KEY `roles_users_fk` (`role_name`), ADD KEY `id_2` (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `bills`
--
ALTER TABLE `bills`
MODIFY `bill_number` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `ingredients`
--
ALTER TABLE `ingredients`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
MODIFY `number` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `payement_modes`
--
ALTER TABLE `payement_modes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `shops`
--
ALTER TABLE `shops`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `articles`
--
ALTER TABLE `articles`
ADD CONSTRAINT `orders_articles_fk` FOREIGN KEY (`order_number`) REFERENCES `orders` (`number`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `products_articles_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `bills`
--
ALTER TABLE `bills`
ADD CONSTRAINT `orders_bills_fk` FOREIGN KEY (`order_number`) REFERENCES `orders` (`number`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `compositions`
--
ALTER TABLE `compositions`
ADD CONSTRAINT `products_compositions_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `ingredients_compositions_fk` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `employees`
--
ALTER TABLE `employees`
ADD CONSTRAINT `users_employees_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `shops_employees_fk` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `orders`
--
ALTER TABLE `orders`
ADD CONSTRAINT `shops_orders_fk` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `users_orders_fk` FOREIGN KEY (`deliveryman_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `users_orders_fk1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `users_orders_fk2` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `payments`
--
ALTER TABLE `payments`
ADD CONSTRAINT `bills_payments_fk` FOREIGN KEY (`bill_number`) REFERENCES `bills` (`bill_number`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `payement_modes_payments_fk` FOREIGN KEY (`payment_mode_id`) REFERENCES `payement_modes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `stocks`
--
ALTER TABLE `stocks`
ADD CONSTRAINT `shops_stocks_fk` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `ingredients_stocks_fk` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
ADD CONSTRAINT `roles_users_fk` FOREIGN KEY (`role_name`) REFERENCES `roles` (`role_name`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
